﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T1___Nombre___Carnet
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi Segundo programa");
            Console.WriteLine("Introduzca su nombre");
            string Nombre = Console.ReadLine();
            Console.WriteLine("Introduzca su edad");
            string Edad = Console.ReadLine();
            Console.WriteLine("Introduzca su Carrera");
            string Carrera = Console.ReadLine();
            Console.WriteLine("Introduzca su Carnet");
            string Carnet = Console.ReadLine();
            Console.Write("Soy " + Nombre + " tengo " + Edad + " años y estudio la carrera de " + Carrera + " mi numero de carnet es " + Carnet);
            Console.ReadKey();
        }
    }
}
