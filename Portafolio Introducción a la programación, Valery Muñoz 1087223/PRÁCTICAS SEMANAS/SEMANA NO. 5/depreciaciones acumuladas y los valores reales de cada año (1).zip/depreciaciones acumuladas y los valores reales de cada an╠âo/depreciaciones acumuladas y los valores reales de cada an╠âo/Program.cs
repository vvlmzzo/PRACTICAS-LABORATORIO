﻿Console.WriteLine("Ingrese El valor del vehiculo:");
Double ValorVehiculo = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("Ingrese El valor de rescate:");
Double ValorRescate = Convert.ToDouble(Console.ReadLine());
Double ValorReal = ValorVehiculo;
Double DepAcumulada = 0;
Double DepAnual = (ValorVehiculo - ValorRescate) / 6;
for (Int16 i = 1; i < 7; i++)
{
    ValorReal = ValorReal - DepAnual;
    DepAcumulada = DepAcumulada + DepAnual;
    Console.WriteLine("Año " + Convert.ToString(i) + ". ValorReal: " + Convert.ToString(ValorReal) + ". Dep Acumulada: " + Convert.ToString(DepAcumulada));
}

Console.ReadKey();

