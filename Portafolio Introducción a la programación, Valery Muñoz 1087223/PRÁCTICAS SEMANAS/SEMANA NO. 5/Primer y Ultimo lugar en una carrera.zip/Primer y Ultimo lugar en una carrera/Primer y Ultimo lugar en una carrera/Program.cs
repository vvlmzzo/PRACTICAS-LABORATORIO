﻿//El programa requerirá el nombre del corredor y la velocidad en la segunda lectura de la linea de la consola
Console.WriteLine("Ingrese el nombre del primer corredor y velocidad");
String Corredor1 = Console.ReadLine();
double Velocidad1 = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("Ingrese el nombre del segundo corredor y velocidad");
String Corredor2 = Console.ReadLine();
double Velocidad2 = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("Ingrese el nombre del tercero corredor y velocidad");
String Corredor3 = Console.ReadLine();
double Velocidad3 = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("Ingrese la distancia de la carrera");
double Distancia = Convert.ToDouble(Console.ReadLine());
//Se procede a calcular el tiempo de los corredores en la carrera de acuerdo a su velocidad
Double Tiempo1 = Distancia / Velocidad1;
Double Tiempo2 = Distancia / Velocidad2;
Double Tiempo3 = Distancia / Velocidad3;

String NombrePrimerLugar = Corredor1;
Double TiempoPrimerLugar = Tiempo1;

String NombreUltimoLugar = Corredor1;
Double TiempoUltimoLugar = Tiempo1;
//Calculo del Primer lugar
if (TiempoPrimerLugar > Tiempo2)
{
    NombrePrimerLugar = Corredor2;
    TiempoPrimerLugar = Tiempo2;

    if (TiempoPrimerLugar > Tiempo3)
    {
        NombrePrimerLugar = Corredor3;
        TiempoPrimerLugar = Tiempo3;
    }

}
else
{

    if (TiempoPrimerLugar > Tiempo3)
    {
        NombrePrimerLugar = Corredor3;
        TiempoPrimerLugar = Tiempo3;
    }
}

//Calculo del Último lugar

if (TiempoUltimoLugar < Tiempo2)
{
    NombreUltimoLugar = Corredor2;
    TiempoUltimoLugar = Tiempo2;

    if (TiempoUltimoLugar < Tiempo3)
    {
        NombreUltimoLugar = Corredor3;
        TiempoUltimoLugar = Tiempo3;
    }

}
else
{

    if (TiempoUltimoLugar < Tiempo3)
    {
        NombreUltimoLugar = Corredor3;
        TiempoUltimoLugar = Tiempo3;
    }
}


Double Dif_Tiempo = TiempoUltimoLugar - TiempoPrimerLugar;



Console.WriteLine("Nombre del Ganador " + NombrePrimerLugar + ". Tiempo oficial: " + Convert.ToString(TiempoPrimerLugar));
Console.WriteLine("Nombre del Ultimo Lugar " + NombreUltimoLugar + ". Tiempo oficial: " + Convert.ToString(TiempoUltimoLugar));
Console.WriteLine("Diferencia de tiempo: " + Convert.ToString(Dif_Tiempo));
Console.ReadLine();



Console.ReadKey();

