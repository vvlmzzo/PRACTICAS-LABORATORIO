﻿Console.WriteLine("Ingresar la cantidad de respuestas correctas dentro de la evaluación");
double correctas = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("Ingresar la cantidad de respuestas incorrectas dentro de la evaluación");
double incorrectas = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("Ingresar la cantidad de respuestas en blanco dentro de la evaluación");
double blanco = Convert.ToDouble(Console.ReadLine());
double NotaFinal = Convert.ToDouble((correctas * 5) + (incorrectas * -1) + (blanco * 0));
Console.WriteLine("El puntaje final de la evaluación es de " + Convert.ToString(NotaFinal));

Console.ReadKey();

