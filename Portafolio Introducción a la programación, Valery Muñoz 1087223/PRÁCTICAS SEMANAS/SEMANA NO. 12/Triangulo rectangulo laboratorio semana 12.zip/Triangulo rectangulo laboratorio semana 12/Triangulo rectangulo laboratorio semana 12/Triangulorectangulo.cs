﻿using System;
namespace Triangulo_rectangulo_laboratorio_semana_12
{
class TrianguloRectangulo
    {
        private double catetoA;
        private double anguloOpuestoA;

        public double ObtenerCatetoA()
        {
            return catetoA;
        }

        public double ObtenerCatetoB()
        {
            double anguloenRad = anguloOpuestoA * Math.PI / 180.0;
            double catetoB = catetoA / Math.Tan(anguloenRad);
            return catetoB;
        }

        public double obtenciondehipotenusa()
        {
            double catetoB = ObtenerCatetoB();
            return Math.Sqrt(catetoA * catetoA + catetoB * catetoB);
        }

        public double ObtenerAnguloOpuestoA()
        {
            return anguloOpuestoA;
        }

        public double ObtenerAnguloOpuestoB()
        {
            return 90.0 - anguloOpuestoA;
        }

        public double ObtenerArea()
        {
            double catetoB = ObtenerCatetoB();
            return 0.5 * catetoA * catetoB;
        }

        public void SetCatetoA(double valor)
        {
            catetoA = valor;
        }

        public void SetAnguloOpuestoA(double valor)
        {
            anguloOpuestoA = valor;
        }
    }
}

