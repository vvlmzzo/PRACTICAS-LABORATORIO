﻿using Triangulo_rectangulo_laboratorio_semana_12;

class Program
{
    static void Main()
    {
        TrianguloRectangulo objTriangulo = new TrianguloRectangulo();

        Console.WriteLine("Ingrese la longitud del cateto A en metros:");
        double catetoA = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Ingrese la amplitud del ángulo opuesto al cateto A en grados:");
        double anguloOpuestoA = Convert.ToDouble(Console.ReadLine());

        objTriangulo.SetCatetoA(catetoA);
        objTriangulo.SetAnguloOpuestoA(anguloOpuestoA);

        Console.WriteLine("Valor de cateto A: " + objTriangulo.ObtenerCatetoA().ToString("0.###") + " metros");
        Console.WriteLine("Valor de cateto B: " + objTriangulo.ObtenerCatetoB().ToString("0.###") + " metros");
        Console.WriteLine("Valor de hipotenusa: " + objTriangulo.obtenciondehipotenusa().ToString("0.###") + " metros");
        Console.WriteLine("Valor de ángulo opuesto de A: " + objTriangulo.ObtenerAnguloOpuestoA().ToString("0.###") + " grados");
        Console.WriteLine("Valor de ángulo opuesto de B: " + objTriangulo.ObtenerAnguloOpuestoB().ToString("0.###") + " grados");
        Console.WriteLine("Valor de área: " + objTriangulo.ObtenerArea().ToString("0.###") + " metros cuadrados");
        Console.ReadKey();
    }
}