﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace movimientorectilineo_uniformementevariado
{
    class Program
    {
        static void Main(string[] args)
        {
            //recibimos los datos en string 
            Console.Write("Por favor, introduzca la velocidad inicial, si desea calcularlo presione ENTER: ");
            string Velocidadinicial = Console.ReadLine();

            Console.Write("Por favor, introduzca la velocidad final, si desea calcularlo presione ENTER: : ");
            string Velocidadfinal = Console.ReadLine();

            Console.Write("Por favor, introduzca la aceleracion,si desea calcularlo presione ENTER: : ");
            string Aceleracion = Console.ReadLine();


            Console.Write("Por favor, introduzca el tiempo,si desea calcularlo presione ENTER: : ");
            string Tiempo = Console.ReadLine();

            //Validamos que se haya ingresado los 3 valores.
            Int16 contador = 0;
            double Velocidadinicialn = 0;
            double VelocidadFinaln = 0;
            double Aceleracionn = 0;
            double tiempon = 0;


            if (Velocidadinicial != "")
            {
             //El contador lo que hará es que sumara la cantidad de datos que el usuario brindara
                contador++;


            //El try funcionara de manera que para no cerrar por completo el programa revisara si es posible llevar a cabo el proceso o no 
                try
                {
                    Velocidadinicialn = Convert.ToDouble(Velocidadinicial);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Velocidad Inicial no valido");
                    Console.ReadKey();
                }
            }

            if (Velocidadfinal != "")
            {
                contador++;
                try
                {
                    VelocidadFinaln = Convert.ToDouble(Velocidadfinal);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Velocidad final no valido");
                    Console.ReadKey();
                }
            }

            if (Aceleracion != "")
            {
                contador++;
                try
                {
                    Aceleracionn = Convert.ToDouble(Aceleracion);
                }
                catch (Exception e)
                {
                    Console.WriteLine("aceleracion no valido");
                    Console.ReadKey();
                }
            }

            if (Tiempo != "")
            {
                contador++;
                try
                {
                    tiempon = Convert.ToDouble(Tiempo);
                }
                catch (Exception e)
                {
                   
                    Console.WriteLine("Tiempo no valido");
                    Console.ReadKey();
                }
            }

            if (contador == 4)
            {

                Console.WriteLine("ERROR!! debe de dejar uno en blanco ");
                Console.ReadKey();
                
            }
             if (contador < 3)
            {
                Console.WriteLine("ERROR!! debe de ingresar tres valores ");
                Console.ReadKey();
            }

            if (contador == 3)
            {
                if (tiempon == 0)
                {
                    tiempon = (VelocidadFinaln-Velocidadinicialn)/(Aceleracionn);
                    Console.WriteLine($"El tiempo calculado es de: {tiempon}");
                    Console.ReadLine();
    
                }

                if (VelocidadFinaln == 0)
                {
                    VelocidadFinaln = ((Velocidadinicialn) + ((Aceleracionn)*(tiempon)));
                    Console.WriteLine($"La velocidad final calculada es de: {VelocidadFinaln}");
                    Console.ReadLine();

                }

                if (Velocidadinicialn == 0)
                {
                    Velocidadinicialn = ((VelocidadFinaln))-((Aceleracionn*tiempon));
                    Console.WriteLine($"La velocidad inicial calculada es de: {Velocidadinicialn}");
                    Console.ReadLine();

                }

                if (Aceleracionn == 0)
                {
                    Aceleracionn = (VelocidadFinaln-Velocidadinicialn)/(tiempon);
                    Console.WriteLine($"La aceleración calculada es de: {Aceleracionn}");
                    Console.ReadLine();
                }
                
            }
            Console.ReadKey();
        }
    }
}