﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace operaciones_aritmeticas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ejercicio 1:Operaciones aritméticas");
            Console.WriteLine();

            Console.WriteLine();
            Console.WriteLine("Ingrese su primer número: ");
            double primernumero = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine();
            Console.WriteLine("Ingrese su segundo número: ");
            double segundonumero = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine();

            double suma = primernumero + segundonumero;
            double resta = primernumero - segundonumero;
            double multiplicacion = primernumero * segundonumero;
            double division = primernumero / segundonumero;
            double modulo = primernumero % segundonumero;

            Console.WriteLine("Soluciones de operaciones aritméticas:");
            Console.WriteLine();
            Console.WriteLine($"(Suma) {primernumero} + {segundonumero} = {suma}");
            Console.WriteLine($"(Resta)  {primernumero} - {segundonumero} = {resta}");
            Console.WriteLine($"(Multiplicación) {primernumero} * {segundonumero} = {multiplicacion}");
            Console.WriteLine($"(División) {primernumero} / {segundonumero} = {division}");
            Console.WriteLine($"(Módulo) {primernumero} % {segundonumero} = {modulo}");

            Console.WriteLine();
            Console.WriteLine("Ejercicio 2: Operaciones booleanas");

            Console.WriteLine();
            bool mayorque = primernumero > segundonumero;
            bool menorque = primernumero < segundonumero;
            bool igualdad = primernumero == segundonumero;

            Console.WriteLine("Respuestas de operaciones booleanas:");
            Console.WriteLine();
            Console.WriteLine($"(Mayor que) {primernumero} > {segundonumero} = {mayorque}");
            Console.WriteLine($"(Menor que) {primernumero} < {segundonumero} = {menorque}");
            Console.WriteLine($"(Igualdad) {primernumero} == {segundonumero} = {igualdad}");

            Console.WriteLine();
            Console.Write("Ejercicio 3:Jerarquía de operaciones");
            Console.WriteLine();

            Console.WriteLine();
            Console.WriteLine("Ingrese su primer número (a): ");
            double primernumeroejercicio3 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine();
            Console.WriteLine("Ingrese su segundo número (b): ");
            double segundonumeroejercicio3 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine();
            Console.WriteLine("Ingrese su tercer número (c): ");
            double tercernumeroejercicio3 = Convert.ToDouble(Console.ReadLine());

            double solucion1 = primernumeroejercicio3 * segundonumeroejercicio3 + tercernumeroejercicio3;
            double solucion2 = primernumeroejercicio3 * (segundonumeroejercicio3 + tercernumeroejercicio3);
            double solucion3 = primernumeroejercicio3 / (segundonumeroejercicio3 * tercernumeroejercicio3);
            double solucion4 = (3 * primernumeroejercicio3 + 2 * segundonumeroejercicio3) / (tercernumeroejercicio3 * tercernumeroejercicio3);

            Console.WriteLine();
            Console.WriteLine("Resultados de la jerarquía de operaciones");

            Console.WriteLine($"{primernumeroejercicio3} * {segundonumeroejercicio3} + {tercernumeroejercicio3} = {solucion1}");
            Console.WriteLine($"{primernumeroejercicio3} * ({segundonumeroejercicio3} + {tercernumeroejercicio3}) = {solucion2}");
            Console.WriteLine($"{primernumeroejercicio3} / ({segundonumeroejercicio3} * {tercernumeroejercicio3}) = {solucion3}");
            Console.WriteLine($"({3 * primernumeroejercicio3} + {2 * segundonumeroejercicio3}) / ({tercernumeroejercicio3 * tercernumeroejercicio3}) = {solucion4}");

            Console.WriteLine();
            Console.Write("Solución de fórmula cuadrática:");
            Console.WriteLine();

            double cuadratica = segundonumeroejercicio3 * segundonumeroejercicio3 - 4 * primernumeroejercicio3 * tercernumeroejercicio3;

            Console.WriteLine();
            if (cuadratica >= 0)
            {
                double x1 = (-segundonumeroejercicio3 + Math.Sqrt(cuadratica)) / (2 * primernumeroejercicio3);
                double x2 = (-segundonumeroejercicio3 - Math.Sqrt(cuadratica)) / (2 * primernumeroejercicio3);
                Console.WriteLine($"Las dos soluciones de la fórmula cuadrática son x1 = {x1} y x2 = {x2}");
            }
            else if (cuadratica == 0)
            {

                double x = -segundonumeroejercicio3 / (2 * primernumeroejercicio3);
                Console.WriteLine($"La solución de la fórmula es x = {x}");
            }
            else
            {
                Console.WriteLine("No existen soluciones reales.");
            }
            Console.ReadKey();
        }
    }
}