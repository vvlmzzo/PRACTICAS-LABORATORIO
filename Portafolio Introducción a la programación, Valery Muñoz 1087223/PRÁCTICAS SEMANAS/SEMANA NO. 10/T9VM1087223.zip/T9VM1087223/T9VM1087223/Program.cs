﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using T9VM1087223;

namespace tarealaboratorio_9
{
    class Program
    {
        static void Main(string[] args)
        {
            Motocicleta objMotocicleta = new Motocicleta();
            objMotocicleta.crearmotocicleta(2019, 1000, "MTT Y2K", 0.12);

            Console.WriteLine("Modelo: " + objMotocicleta.Modelo);
            Console.WriteLine("Precio: " + objMotocicleta.Precio);
            Console.WriteLine("Marca: " + objMotocicleta.Marca);
            Console.WriteLine("IVA: " + objMotocicleta.Iva);

            double preciodeiva = 1000 * 1.12;
            double pagodeiva = preciodeiva - 1000;

            Console.WriteLine("El precio de la motocicleta sin el valor de IVA fue presentado anteriormente");
            Console.WriteLine("El valor de IVA incluido junto al total sería de: Q" + preciodeiva);
            Console.WriteLine("El monto del IVA para dicha motocicleta es de: Q" + pagodeiva);
            Console.ReadKey();
        }
    }
}