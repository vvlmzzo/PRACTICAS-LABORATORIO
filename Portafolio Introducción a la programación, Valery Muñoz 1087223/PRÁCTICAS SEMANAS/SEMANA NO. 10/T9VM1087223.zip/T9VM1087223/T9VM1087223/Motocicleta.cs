﻿using System;
namespace T9VM1087223
{
    public class Motocicleta
    {
        private int modelo = 2019;
        private double precio = 1000.00;
        private string marca;
        private double iva = 0.12;

        public int Modelo { get => modelo; set => modelo = value; }

        public double Precio { get => precio; set => precio = value; }

        public string Marca { get => marca; set => marca = value; }

        public double Iva { get => iva; set => iva = value; }

        public void crearmotocicleta(int _modelo, double _precio, string _marca, double _iva)
        {
            this.modelo = _modelo;
            this.precio = _precio;
            this.marca = _marca;
            this.iva = _iva;
        }

    }
}

