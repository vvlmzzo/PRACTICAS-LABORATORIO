﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tarea_laboratorio7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Calculos de series matemáticas");
            Console.WriteLine();
            Console.WriteLine("Por favor seleccionar una opcion entre a, b o c ");
            Console.WriteLine();
            Console.WriteLine("a. (1 / 1) + (1 / 2) + (1 / 3) + … + (1 / N)");
            Console.WriteLine();
            Console.WriteLine("b. (1 / 2^1) + (1 / 2^2) + (1 / 2^3) + … + (1 / 2^N)");
            Console.WriteLine();
            Console.WriteLine("c. ∑ 𝑥^𝑘 * 𝑎^(𝑛−𝑘) / 𝑛");
            Console.WriteLine();


            char opcion = Console.ReadLine().ToLower()[0];

            switch (opcion)
            {
                case 'a':
                    SerieA();
                    break;
                case 'b':
                    SerieB();
                    break;
                case 'c':
                    SerieC();
                    break;
                default:
                    Console.WriteLine();
                    Console.WriteLine("La opción elegida no es válida ");
                    break;
            }
        }

        static void SerieA()
        {
            Console.WriteLine();
            Console.Write("Ingrese el valor de la variable N: ");
            if (int.TryParse(Console.ReadLine(), out int n) && n > 0)
            {
                double resultado = 0.0;
                for (int i = 1; i <= n; i++)
                {
                    resultado += 1.0 / i;
                }
                Console.WriteLine($"El resultado de la serie seleccionada es: {resultado}");
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Ingrese un número entero mayor que 0 ");
            }
        }

        static void SerieB()
        {
            Console.WriteLine();
            Console.Write("Ingrese el valor de la variable N: ");
            if (int.TryParse(Console.ReadLine(), out int n) && n > 0)
            {
                double resultado = 0.0;
                for (int i = 1; i <= n; i++)
                {
                    resultado += 1.0 / Math.Pow(2, i);
                }
                Console.WriteLine();
                Console.WriteLine($"El resultado de la serie es: {resultado}");
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Ingrese un número entero mayor que 0 ");
            }
        }

        static void SerieC()
        {
            Console.WriteLine();
            Console.Write("Ingrese el valor de la variable x: ");
            if (int.TryParse(Console.ReadLine(), out int x))
            {
                Console.WriteLine();
                Console.Write("Ingrese el valor de la variable a: ");
                if (int.TryParse(Console.ReadLine(), out int a))
                {
                    Console.WriteLine();
                    Console.Write("Ingrese el valor de la variable n: ");
                    if (int.TryParse(Console.ReadLine(), out int n) && n >= 0)
                    {
                        double resultado = 0.0;
                        for (int k = 0; k <= n; k++)
                        {
                            resultado += Math.Pow(x, k) * Math.Pow(a, n - k) / n;
                        }
                        Console.WriteLine($"El resultado de la serie seleccionada es: {resultado}");
                    }
                    else
                    {
                        Console.WriteLine();
                        Console.WriteLine("Ingrese un número entero no negativo para 'n' ");
                    }
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("Ingrese un número entero para 'a'");
                }
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Ingrese un número entero para 'x'");
            }
            Console.ReadKey();
        }
    }
}
