﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace repaso_parcial
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduzca 3 cantidades de dinero con su respectiva moneda (USD o GTQ):");

            double primeracantidad, segundacantidad, terceracantidad;
            string moneda1, moneda2, moneda3;

            Console.WriteLine();
            Console.Write("Cantidad 1: ");
            if (double.TryParse(Console.ReadLine(), out primeracantidad))
            {
                Console.Write("Tipo de moneda (USD o GTQ): ");
                moneda1 = Console.ReadLine().ToUpper();

                if (moneda1 == "USD")
                {
                    primeracantidad *= 7.83; // Convertir dólares a quetzales
                }
                else if (moneda1 != "GTQ")
                {
                    Console.WriteLine();
                    Console.WriteLine("Tipo de moneda no válida. Use USD o GTQ.");
                    return;
                }
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Entrada no válida. Ingrese un número válido.");
                return;
            }

            Console.WriteLine();
            Console.Write("Cantidad 2: ");
            if (double.TryParse(Console.ReadLine(), out segundacantidad))
            {
                Console.Write("Tipo de moneda (USD o GTQ): ");
                moneda2 = Console.ReadLine().ToUpper();

                if (moneda2 == "USD")
                {
                    segundacantidad *= 7.83; // Convertir dólares a quetzales
                }
                else if (moneda2 != "GTQ")
                {
                    Console.WriteLine();
                    Console.WriteLine("Tipo de moneda no válida. Use USD o GTQ.");
                    return;
                }
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Entrada no válida. Ingrese un número válido.");
                return;
            }

            Console.WriteLine();
            Console.Write("Cantidad 3: ");
            if (double.TryParse(Console.ReadLine(), out terceracantidad))
            {
                Console.Write("Tipo de moneda (USD o GTQ): ");
                moneda3 = Console.ReadLine().ToUpper();

                if (moneda3 == "USD")
                {
                    terceracantidad *= 7.83; // Convertir dólares a quetzales
                }
                else if (moneda3 != "GTQ")
                {
                    Console.WriteLine();
                    Console.WriteLine("Tipo de moneda no válida. Use USD o GTQ.");
                    return;
                }
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Entrada no válida. Ingrese un número válido.");
                return;
            }

            // Ordenar las cantidades en orden ascendente (usando variables)
            double temp;
            if (primeracantidad > segundacantidad)
            {
                temp = primeracantidad;
                primeracantidad = segundacantidad;
                segundacantidad = temp;
            }
            if (segundacantidad > terceracantidad)
            {
                temp = segundacantidad;
                segundacantidad = terceracantidad;
                terceracantidad = temp;
            }
            if (primeracantidad > segundacantidad)
            {
                temp = primeracantidad;
                primeracantidad = segundacantidad;
                segundacantidad = temp;
            }

            // Mostrar las cantidades en orden ascendente en quetzales (GTQ)
            Console.WriteLine("Cantidades en orden ascendente en quetzales (GTQ):");
            Console.WriteLine();
            Console.WriteLine($"{primeracantidad:C2}");
            Console.WriteLine();
            Console.WriteLine($"{segundacantidad:C2}");
            Console.WriteLine();
            Console.WriteLine($"{terceracantidad:C2}");
            Console.ReadKey();
        }
    }
}
