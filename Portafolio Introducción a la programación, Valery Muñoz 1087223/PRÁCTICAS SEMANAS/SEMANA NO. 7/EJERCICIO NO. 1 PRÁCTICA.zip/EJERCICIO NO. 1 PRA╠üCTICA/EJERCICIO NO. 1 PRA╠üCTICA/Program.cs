﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace repaso_parcial
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Por favor, intruduzca un número entero: ");
            string input = Console.ReadLine();
            int numeroentero;

            if (int.TryParse(input, out numeroentero))
            {
                if (numeroentero > 0)
                {
                    Console.WriteLine();
                    Console.WriteLine("El resultado del entero ingresado es:positivo");
                }
                else if (numeroentero < 0)
                {
                    Console.WriteLine();
                    Console.WriteLine("El resultado del entero ingresado es: negativo");
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("El resultado del entero ingresado es: cero");
                }
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Se ha producido un error, el número entero es inválido");
            }
            Console.ReadKey();
        }
    }
}