﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace repaso_parcial
{
    class Program
    {
        static void Main(string[] args)
        {
            double monto;

            Console.WriteLine();
            Console.Write("Introduzca el monto de la compra realizada: ");
            string input = Console.ReadLine();

            if (double.TryParse(input, out monto))
            {
                double descuento = 0;

                if (monto >= 400)
                {
                    if (monto <= 1000)
                    {
                        descuento = monto * 0.07; 
                    }
                    else
                    {
                        if (monto <= 5000)
                        {
                            descuento = monto * 0.10; 
                        }
                        else
                        {
                            if (monto <= 15000)
                            {
                                descuento = monto * 0.15; 
                            }
                            else
                            {
                                descuento = monto * 0.25; 
                            }
                        }
                    }
                }

                Console.WriteLine();
                Console.Write("¿Cuenta con algún código de descuento? (Si o No): ");
                string respuesta = Console.ReadLine().ToUpper();

                if (respuesta == "Si")
                {
                    descuento += monto * 0.05;
                }

                double montoFinal = monto - descuento;

                Console.WriteLine();
                Console.WriteLine($"El monto final a pagar es de; Q{montoFinal:F2}");
            }
            else
            {
                Console.WriteLine("Se ha producido un error. Ingrese un monto válido.");
            }
            Console.ReadKey();
        }
    }
}


