﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ejercicio2_laboratorio5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio No.2");
            Console.WriteLine();
            Console.Write("Intruduzca un número entre 1 y 7: ");
            if (int.TryParse(Console.ReadLine(), out int numerodedia))
            {
                string diadelasemana;

                if (numerodedia < 1 || numerodedia > 7)
                {
                    Console.WriteLine();
                    Console.WriteLine("Error: El número a ingresar debe estar contenido entre 1 y 7");
                }
                else
                {
                    if (numerodedia == 1)
                    {
                        diadelasemana = "Lunes";
                    }
                    else if (numerodedia == 2)
                    {
                        diadelasemana = "Martes";
                    }
                    else if (numerodedia == 3)
                    {
                        diadelasemana = "Miércoles";
                    }
                    else if (numerodedia == 4)
                    {
                        diadelasemana = "Jueves";
                    }
                    else if (numerodedia == 5)
                    {
                        diadelasemana = "Viernes";
                    }
                    else if (numerodedia == 6)
                    {
                        diadelasemana = "Sábado";
                    }
                    else
                    {
                        diadelasemana = "Domingo";
                    }

                    Console.WriteLine();
                    Console.WriteLine($"El día seleccionado es: {diadelasemana}");
                }
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("El número es inválido, por favor ingresar un número entre 1 y 7");
            }
            Console.ReadKey();
        }
    }
}


